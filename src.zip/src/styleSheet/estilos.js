import { StyleSheet } from 'react-native';

const estilos = StyleSheet.create({
  fundoAmarelo: {
    flex: 1,
    backgroundColor: '#FFD700', // fundo amarelo
    justifyContent: 'center',
    alignItems: 'center',
  },
  containerBranco: {
    backgroundColor: '#fff', // fundo branco
    borderRadius: 20,
    padding: 20,
    width: '90%',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 5, // sombra no Android
  },
  cabecalhoContainer: {
    alignItems: 'center',
    marginBottom: 20,
  },
  cabecalhoBox: {
    backgroundColor: '#f9120a', // fundo primário
    borderWidth: 3,
    borderColor: '#ffd900',
    borderRadius: 10,
    padding: 10,
    alignItems: 'center',
  },
  logo: {
    width: 100,
    height: 100,
    marginBottom: 10,
    resizeMode: 'contain',
  },
  titulo: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#9d1c19',
    borderColor: '#9d1c19',
    borderWidth: 2,
    borderRadius: 5,
    paddingHorizontal: 10,
    textAlign: 'center',
  },
  input: { borderWidth: 1, borderColor: '#ff0000', padding: 8, marginBottom: 10 },
  picker: { height: 50, marginBottom: 10, borderWidth: 1, borderColor: '#ff0000', padding: 8 },
  imagem: { width: 150, height: 150, alignSelf: 'center', marginVertical: 20 },
  resumo: { marginTop: 20, padding: 10, borderWidth: 1, borderColor: '#ccc' },
  rodape: { textAlign: 'center', marginTop: 30, color: '#555' },
});

export default estilos;
