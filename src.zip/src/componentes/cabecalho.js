import React from 'react';
import { View, Text, Image } from 'react-native';
import estilos from '../styleSheet/estilos';

function Cabecalho() {
  return (
    <View style={estilos.cabecalhoContainer}>
      <View style={estilos.cabecalhoBox}>
        <Image source={require('../img/logo.png')} style={estilos.logo} />
        <Text style={estilos.titulo}>Lanchonete App</Text>
      </View>
    </View>
  );
}

export default Cabecalho;
