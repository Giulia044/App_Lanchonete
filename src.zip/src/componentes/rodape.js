import React from 'react';
import { Text } from 'react-native';
import estilos from '../styleSheet/estilos';

function Rodape() {
  return <Text style={estilos.rodape}>Produzido por: Giulia</Text>;
}

export default Rodape;
