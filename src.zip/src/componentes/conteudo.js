import React, { useState } from 'react';
import { View, Text, TextInput, Image, Button } from 'react-native';
import { Picker } from '@react-native-picker/picker';
import estilos from '../styleSheet/estilos';

function Conteudo() {
  const [nome, setNome] = useState('');
  const [lanche, setLanche] = useState('Hambúrguer');
  const [obs, setObs] = useState('');
  const [pedido, setPedido] = useState(null);

  const imagens = {
    'Hambúrguer': require('../img/hamburguer.png'),
    'Pizza Inteira': require('../img/pizzaInteira.png'),
    'Pizza Fatia': require('../img/pizzaFatia.png'),
    'Sopa': require('../img/sopa.png'),
    'Batata Frita': require('../img/batataFrita.png'),
    'Hot Dog': require('../img/hotdog.png'),
    'Sanduíche': require('../img/sanduiche.png'),
  };

  const fazerPedido = () => {
    setPedido({ nome, lanche, obs });
  };

  return (
    <View>
      <Text>Digite seu nome:</Text>
      <TextInput style={estilos.input} value={nome} onChangeText={setNome} />

      <Text>Escolha seu lanche:</Text>
      <Picker
        selectedValue={lanche}
        onValueChange={(itemValue) => setLanche(itemValue)}
        style={estilos.picker}
      >
        <Picker.Item label="Hambúrguer" value="Hambúrguer" />
        <Picker.Item label="Pizza Inteira" value="Pizza Inteira" />
        <Picker.Item label="Pizza Fatia" value="Pizza Fatia" />
        <Picker.Item label="Sopa" value="Sopa" />
        <Picker.Item label="Batata Frita" value="Batata Frita" />
        <Picker.Item label="Hot Dog" value="Hot Dog" />
        <Picker.Item label="Sanduíche" value="Sanduíche" />
      </Picker>

      <Image source={imagens[lanche]} style={estilos.imagem} />

      <Text>Observações:</Text>
      <TextInput style={estilos.input} value={obs} onChangeText={setObs} />

      <Button title="Fazer Pedido" onPress={fazerPedido} color="green" />

      {pedido && (
        <View style={estilos.resumo}>
          <Text>Pedido de: {pedido.nome}</Text>
          <Text>Lanche: {pedido.lanche}</Text>
          <Text>Observação: {pedido.obs}</Text>
        </View>
      )}
    </View>
  );
}

export default Conteudo;
