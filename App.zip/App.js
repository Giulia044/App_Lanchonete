import React from 'react';
import { View } from 'react-native';
import Cabecalho from './src/componentes/cabecalho';
import Conteudo from './src/componentes/conteudo';
import Rodape from './src/componentes/rodape';
import estilos from './src/styleSheet/estilos';

function App() {
  return (
    <View style={estilos.fundoAmarelo}>
      <View style={estilos.containerBranco}>
        <Cabecalho />
        <Conteudo />
        <Rodape />
      </View>
    </View>
  );
}

export default App;
